# Student Skill & Internship Sharing Platform — Website MVP

A runnable Java web application for the Code Quest project.

## Technology
- Java 17
- Spring Boot 3
- Spring MVC + Thymeleaf (server-rendered website)
- Spring Data JPA / Hibernate
- Spring Security with BCrypt password hashing
- MySQL

## Features included
1. Student registration and login
2. Add/remove skills with Beginner, Intermediate and Advanced levels
3. Search students by skill
4. Browse internship opportunities
5. Post internship opportunities
6. Apply for internships (duplicate applications are blocked)
7. View applications and withdraw while status is `Applied`

## Requirements
- JDK 17+
- Maven 3.8+
- MySQL 8+

## Run locally
1. Create a MySQL user/database or use the local root account.
2. Open `src/main/resources/application.properties`.
3. Set `spring.datasource.username` and `spring.datasource.password` to your own local MySQL credentials. Do not share or commit real passwords.
4. From this project folder, run:

   ```bash
   mvn spring-boot:run
   ```

5. Open `http://localhost:8080` in your browser.
6. Select **Create an account**, register, and sign in.

Hibernate creates/updates the tables automatically because `spring.jpa.hibernate.ddl-auto=update` is configured for local development.

## Main database tables
- `students`
- `skills`
- `student_skills`
- `internships`
- `internship_applications`

Primary keys and foreign keys are managed through JPA relationships. Unique constraints protect student email, skill names, student-skill pairs and duplicate applications.

## Important project notes
- This is a functional local-development MVP, not a production deployment.
- The website uses Java + MySQL. Thymeleaf templates, HTML and CSS render the browser interface; Spring Boot handles server-side Java logic.
- Before public deployment, configure HTTPS, secure secrets using environment variables, add email verification and password reset, add moderation/admin roles, rate limiting, privacy controls and backups.
- Do not use real student contact details in demo data. Use test accounts.
- Review the schema and requirements with your faculty before final submission.

## Suggested demo
Register two test students. Add different skills to each. Search a skill from the peer discovery page. Post an internship, apply from a student account, then show the application status and withdrawal option.
